
joint_multi_WF.m is the main function. All the sub-functions are included in this folder. You need to construct an initial affinity matrix.

If you find the code useful, please cite our paper
@ARTICLE{9154586,
  author={Y. {Jia} and W. {Wu} and R. {Wang} and J. {Hou} and S. {Kwong}},
  journal={IEEE Transactions on Neural Networks and Learning Systems}, 
  title={Joint Optimization for Pairwise Constraint Propagation}, 
  year={2020},
  volume={},
  number={},
  pages={1-13},
  doi={10.1109/TNNLS.2020.3009953}}
  
  Any questions, please contact me yhjia at seu dot edu dot cn
