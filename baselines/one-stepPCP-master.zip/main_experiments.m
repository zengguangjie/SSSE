clc;
clear;
addpath(genpath(pwd))

% datasets = ['Yale', 'ORL', 'COIL20', 'COIL100', 'USPS', 'MNIST', 'CovType'];
% datasets = ["10X_PBMC", "Human_kidney", "Mouse_bladder", "Worm_neuron", "CITE_PBMC", "Human_liver", "Baron_human", "Macosko_mouse_retina", "Shekhar_mouse_retina"];
datasets = ["2100cells/mouse_bladder", "2100cells/worm_neuron", "2100cells/human_kidney", "2100cells/10X_PBMC"];
for index = 1:length(datasets)


dataseti = convertStringsToChars(datasets(index))

inputName = ['datasets/', dataseti, '.mat'];
data = load(inputName);
X = double(data.fea);
X = NormalizeFea(X);
y = data.gnd;
sizeX = size(X);
num_points = sizeX(1);
k = max(y);
constraints_num = int32(0.4*sizeX(1));
ARIs = [];
NMIs = [];
times = [];
for repeat_time = 1:10
tStart = tic;

F0 = Get_Constraints(y,constraints_num,'MCL');
p = floor(log2(sizeX(1)))+1;

% KNN graph generated using knnsearch
[rows,weights] = knnsearch(X,X,'K',p,'Sort',false,...
    'IncludeTies',true);
for ii = 1:size(weights,1)
    weightsii = weights{ii,1};
    weights{ii,1} = weightsii(:,1:p);
end
for ii = 1:size(rows,1)
    rowsii = rows{ii,1};
    rows{ii,1} = rowsii(:,1:p);
end
mean_weights = cell2mat(weights);
mean_weights = mean(mean_weights(:,2:p),2);
kscale = cell(size(weights));
for ii = 1:size(mean_weights,1)
    cellii = [];
    for jj = 1:p
        cellii(jj) = mean_weights(ii);
    end
    kscale(ii) = num2cell(cellii,[1,2]);
end
A = makeSimilarityMatrixFromIndices(rows,weights,kscale,num_points);
A = full(A+A')/2;
para.beta = 1;
para.maxiter= 10;
para.tau = 0.0001;
para.maxtau = 100000000;
para.rho = 1.1;
[ACC,NMI,label_new,S,F] = joint_multi_WF(A,A,F0,para,k,y,10);
y_pred = cell2mat(label_new(1,10));
tEnd = toc(tStart);
[statistic,ACC,PE,RE,ARI,NMI]=accuray_measures(y_pred,y);
ARI, NMI
ARIs = [ARIs,ARI];
NMIs = [NMIs,NMI];
times = [times, tEnd];
end
% mean(ARIs), mean(NMIs)

score_fname = ['results/', dataseti, '.txt'];
fid = fopen(score_fname, 'w');
fprintf(fid, 'ARI\t');
for i = 1:length(ARIs)
    fprintf(fid, '%.8f\t', ARIs(i));
end
fprintf(fid, 'average: %.8f\t', mean(ARIs));
fprintf(fid, 'std: %.8f\n NMI:\t', std(ARIs));
for i = 1:length(NMIs)
    fprintf(fid, '%.8f\t', NMIs(i));
end
fprintf(fid, 'average: %.8f\t', mean(NMIs));
fprintf(fid, 'std: %.8f\n times:\t', std(NMIs));

for i = 1:length(times)
    fprintf(fid, '%.8f\t', times(i));
end
fprintf(fid, 'average: %.8f\t', mean(times));
fprintf(fid, 'std: %.8f\n', std(times));

end


function S = makeSimilarityMatrixFromIndices(rows,weights,kscale,N)
% rows and weights are always cells (rangesearch and knnsearch-with-ties)
weights = exp(-([weights{:}]./[kscale{:}]).^2);

% Get column indices
cols = ones(size(weights));
colind = 1;
for idx = 1:N
    num = length(rows{idx});
    cols(colind:colind+num-1) = idx*cols(colind:colind+num-1);
    colind = colind+num;
end
rows = [rows{:}];

% Return a sparse similarity matrix. 'sparse' does not accept weights with
% single precision. Convert weights to double.
S = sparse(rows,cols,double(weights),N,N);
end

