clc;
clear;
addpath(genpath(pwd))

% datasets = ["Yale", "ORL", "COIL20", "COIL100", "USPS", "MNIST", "CovType"];
% datasets = ["Isolet1"];
datasets = ["2100cells/mouse_bladder", "2100cells/worm_neuron", "2100cells/human_kidney", "2100cells/10X_PBMC"];
for index = 1:length(datasets)


dataseti = convertStringsToChars(datasets(index))

inputName = ['datasets/', dataseti, '.mat'];
data = load(inputName);
X = double(data.fea);
y = data.gnd;
k=max(y);
fea = NormalizeFea(X);
% fulldata = fea';%fulldata=D*N
% Trans_fulldata=fea;
sizeX = size(X);
constraints_num = int32(0.2*sizeX(1));

ARIs = [];
NMIs = [];
times = [];
for repeat_time = 1:10
tStart = tic;
%% W
nnparams=cell(1);
nnparams{1}='knn';
opts.K =4; 
opts.maxblk = 1e7;
opts.metric = 'eucdist';
nnparams{2}=opts;
T_G=slnngraph(fea',[],nnparams);
% size(fea)
% T_G = EuDist2(fea, fea);

W=zeros(sizeX(1));
for i = 1:sizeX(1)
    ind = find(T_G(:,i)~=0);
    W(ind,i) = exp(-0.25*T_G(ind,i));  
end
W=(W+W')/2;

% construct affinity matrix (D^-1/2)*W*(D^-1/2)
GD = full(sum(W,2));
D_mhalf = spdiags(GD.^-.5,0,sizeX(1),sizeX(1));
graphL = D_mhalf*W*D_mhalf;
[Z,~]=Get_Constraints(y,constraints_num,'ML');

%% PCPSNMF
mu=0.5;
alpha=1;%optimal

[Vn,K] = CSNMF(W,mu,k,Z,alpha);
[tmp, label] = max(Vn, [], 2); 
tEnd = toc(tStart);
[statistic,ACC,PE,RE,ARI,NMI]=accuray_measures(label,y);
ARI, NMI
ARIs = [ARIs,ARI];
NMIs = [NMIs,NMI];
times = [times, tEnd];
end
mean(ARIs), mean(NMIs)

score_fname = ['results/', dataseti, '.txt'];
fid = fopen(score_fname, 'w');
fprintf(fid, 'ARI\t');
for i = 1:length(ARIs)
    fprintf(fid, '%.8f\t', ARIs(i));
end
fprintf(fid, 'average: %.8f\t', mean(ARIs));
fprintf(fid, 'std: %.8f\n NMI:\t', std(ARIs));
for i = 1:length(NMIs)
    fprintf(fid, '%.8f\t', NMIs(i));
end
fprintf(fid, 'average: %.8f\t', mean(NMIs));
fprintf(fid, 'std: %.8f\n times:\t', std(NMIs));

for i = 1:length(times)
    fprintf(fid, '%.8f\t', times(i));
end
fprintf(fid, 'average: %.8f\t', mean(times));
fprintf(fid, 'std: %.8f\n', std(times));

end
