function disp(DS)
%DISP displays the dataset fields

disp(' [dataset object]');
disp(struct(DS))

