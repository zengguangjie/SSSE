import argparse
import os
import time

import numpy as np
from sklearn import metrics
import scipy
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from ete3 import Tree, TreeNode
from tqdm import tqdm

import cobra


def dendrogram_purity_expected(t, y, n_sample=1000):
    n_instance = y.shape[0]
    y = y.astype(int)
    y_onehot = np.zeros((y.shape[0], y.max() + 1))
    y_onehot[np.arange(y.shape[0]), y] = 1
    cluster_dict = {}
    for i in range(y_onehot.shape[1]):
        indicesi = np.argwhere(y_onehot[:, i] == 1).flatten()
        cluster_indices = np.argwhere(y_onehot[:, i] == 1).flatten().tolist()
        for j in indicesi:
            cluster_dict[j] = cluster_indices
    purity_list = []
    leaves_dict = {}
    for leaf in t.get_leaves():
        leaves_dict[int(leaf.name)] = leaf
    for index_sample in tqdm(range(n_sample)):
        nodeID_i = np.random.randint(n_instance)
        cluster_indices = cluster_dict[nodeID_i]
        nodeID_j = np.random.choice(cluster_indices)
        nodei = leaves_dict[nodeID_i]
        nodej = leaves_dict[nodeID_j]
        ancestor = t.get_common_ancestor(nodei, nodej)
        ancestor_leaves = [int(i.name) for i in ancestor.get_leaves()]
        assert nodeID_i in ancestor_leaves
        assert nodeID_j in ancestor_leaves
        purity = len(set(ancestor_leaves).intersection(cluster_indices)) / len(ancestor_leaves)
        purity_list.append(purity)
    return np.mean(purity_list)

def clustering2ete(clusterings):
    clusterings = np.array(clusterings)
    tree = Tree(name=0)
    partition_last = np.zeros(clusterings.shape[1])
    nodes_last = {}
    nodes_last[0] = tree
    for i in range(clusterings.shape[0]-1, -1, -1):
        partition = clusterings[i,:]
        nodes = {}
        for j_last in np.unique(partition_last):
            indices_j_last = np.argwhere(partition_last == j_last).flatten()
            node_j_last = nodes_last[j_last]
            for j in np.unique(partition[indices_j_last]):
                node_j = node_j_last.add_child(name=j)
                nodes[j] = node_j
        partition_last = partition
        nodes_last = nodes
    for j_last in np.unique(partition_last):
        indices_j_last = np.argwhere(partition_last == j_last).flatten()
        node_j_last = nodes_last[j_last]
        for j in indices_j_last:
            node_j_last.add_child(name=j)
    return tree





parser = argparse.ArgumentParser()
# parser.add_argument("dataset", default="data/iris_with_labels.data", help="the dataset to cluster")
# parser.add_argument("output", default="output", help="file to which resulting clustering will be stored")
parser.add_argument("-nsi","--num_superinstances", help="the number of super-instances",type=int,default=50)
parser.add_argument("-ls","--labels_specified", help="should be set if last column of dataset contains cluster labels",action="store_true")
parser.add_argument("-i","--interactive", help="if this flag is set, the user will be queried for pairwise relations through the command line",action="store_true")

args = parser.parse_args()

args.output = '/home/zengguangjie/cobra/output'
args.dataset = '/home/zengguangjie/cobra/data/iris_with_labels.data'
args.num_superinstances = 50
args.labels_specified = True
args.interactive = False

# with open(args.dataset) as file:
#     X = np.asarray([[float(digit) for digit in line.split(',')] for line in file])
#
# labels = None
# if args.labels_specified:
#     labels = X[:,-1]
#     X = X[:,:-1]
for dataset in ["Yale", "ORL", "COIL20", "COIL100", "USPS", "MNIST", "CovType"]:
    # path = "datasets/{}.mat".format(dataset)
    data_file = scipy.io.loadmat("datasets/{}.mat".format(dataset))
    # print(data_file.keys())
    X = data_file["fea"]
    X = StandardScaler().fit_transform(X)
    y = data_file["gnd"].squeeze()
    n_train = int(np.floor(np.sqrt(0.4 * X.shape[0]))) + 1
    print(n_train)
    DPs = []
    times = []
    with open("results/n_train_{}2.txt".format(dataset), 'w') as f:
        for i in range(10):
            # ARI, NMI, time_i = main(dataset)
            train_indices = np.random.choice(X.shape[0], size=n_train)
            time1 = time.time()
            clusterer = cobra.COBRA(args.num_superinstances)
            clusterings, runtimes, ml, cl = clusterer.cluster(X, y, train_indices)
            time2 = time.time()
            t = clustering2ete(clusterings)
            DP = dendrogram_purity_expected(t, y)
            print(DP, time2-time1)
            DPs.append(DP)
            times.append(time2-time1)


        f.write("NMI:\t")
        for i in range(len(DPs)):
            f.write("{}\t".format(DPs[i]))
        f.write("average:\t{}\t".format(np.mean(DPs)))
        f.write("std:\t{}\n".format(np.std(DPs)))

        f.write("time:\t")
        for i in range(len(times)):
            f.write("{}\t".format(times[i]))
        f.write("average:\t{}\t".format(np.mean(times)))
        f.write("std:\t{}\n".format(np.std(times)))

        print(np.mean(DPs))




