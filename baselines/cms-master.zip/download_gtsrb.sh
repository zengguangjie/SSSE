#!/bin/sh

wget https://sid.erda.dk/public/archives/daaeac0d7ce1152aea9b61d9f1e19370/GTSRB-Training_fixed.zip -P data
unzip data/GTSRB-Training_fixed.zip -d data
