import time


def cms_img(x, cl, ml, use_cuda=True):
    from CMS import CMS, AutoLinearPolicy
    from CMS.Constraints import transitive_closure_constraints

    iterations = 80

    cl = transitive_closure_constraints(cl, ml, len(x))

    pol = AutoLinearPolicy(x, iterations)
    cms = CMS(pol, max_iterations=iterations, blurring=False, kernel=.2, use_cuda=use_cuda, label_merge_k=.99)

    return cms.fit_predict(x, cl)


def main(dataset):
    import sys
    import numpy as np
    from Util.Sampling import generate_constraints_fixed_count
    from Util.CsvWriter import CsvWriter
    from Util.Datasets import load_embeddings
    from sklearn.metrics import normalized_mutual_info_score, adjusted_rand_score
    from argparse import ArgumentParser

    data_choices = {
        'gtsrb': lambda: load_embeddings(which='gtsrb', sample='default'),
        'mnist': lambda: load_embeddings(which='mnist', sample='default'),
        'fashion-mnist': lambda: load_embeddings(which='fashion-mnist', sample='default'),
        'COIL20': lambda: load_embeddings(which='COIL20', sample=None),
        'COIL100': lambda: load_embeddings(which='COIL100', sample=None),
        'ORL': lambda: load_embeddings(which='ORL', sample=None),
        'Yale': lambda: load_embeddings(which='Yale', sample=None),
        'YaleB_32x32': lambda: load_embeddings(which='YaleB_32x32', sample=None),
        'Banknote': lambda: load_embeddings(which='Banknote', sample=None),
        'Isolet1': lambda: load_embeddings(which='Isolet1', sample=None),
        '10X_pbmc': lambda: load_embeddings(which='10X_pbmc', sample=None),
        # 'mouse_bladder': lambda: load_embeddings(which='mouse_bladder', sample=None),
        # 'human_kidney': lambda: load_embeddings(which='human_kidney', sample=None),
        # 'worm_neuron': lambda: load_embeddings(which='worm_neuron', sample=None),
        'OpticalDigits': lambda: load_embeddings(which='OpticalDigits', sample=None),
        'USPS': lambda: load_embeddings(which='USPS', sample=None),
        'MNIST': lambda: load_embeddings(which='MNIST', sample=None),
        '10X_PBMC': lambda: load_embeddings(which='10X_PBMC', sample=None),
        'Human_kidney': lambda: load_embeddings(which='Human_kidney', sample=None),
        'Mouse_bladder': lambda: load_embeddings(which='Mouse_bladder', sample=None),
        'Worm_neuron': lambda: load_embeddings(which='Worm_neuron', sample=None),
        'CITE_PBMC': lambda: load_embeddings(which='CITE_PBMC', sample=None),
        'Human_liver': lambda: load_embeddings(which='Human_liver', sample=None),
        'Baron_human': lambda: load_embeddings(which='Baron_human', sample=None),
        'Macosko_mouse_retina': lambda: load_embeddings(which='Macosko_mouse_retina', sample=None),
        'Shekhar_mouse_retina': lambda: load_embeddings(which='Shekhar_mouse_retina', sample=None),
    }

    parser = ArgumentParser()
    parser.add_argument('--data', choices=data_choices.keys())
    parser.add_argument('--repeats', metavar='N', type=int, default=100)
    parser.add_argument('--constraint-factor', metavar='F', type=float, default=1.)
    parser.add_argument('--nocuda', action="store_false", dest='use_cuda')

    args = parser.parse_args()
    args.data = dataset
    use_cuda = False
    # use_cuda = args.use_cuda
    # print(args.use_cuda)
    args.constraint_factor = 0.4
    args.repeats = 10
    data_func = data_choices[args.data]

    print("Starting cluster_img.py, args = {}".format(args), file=sys.stderr, flush=True)

    file_name = 'cms-img-{}.csv'.format(args.data)

    with CsvWriter(file_name) as writer:
        for run in range(args.repeats):
            print('Run {}/{}'.format(run+1, args.repeats))
            time1 = time.time()
            data = data_func().normalized_linear()
            x, y = data.train
            n_c = int(len(y) * args.constraint_factor)
            cl, ml = generate_constraints_fixed_count(y, n_c)

            y_pred = cms_img(np.copy(x), np.copy(cl), np.copy(ml), use_cuda=use_cuda)
            time2 = time.time()

            nmi = normalized_mutual_info_score(y, y_pred)
            ari = adjusted_rand_score(y, y_pred)
            time_used = time2 - time1
            writer.write_row(algo='cms', data=data.name, ari=ari, nmi=nmi, time=time_used)


if __name__ == '__main__':
    # for dataset in ["Yale", "ORL", "COIL20", "COIL100", "USPS", "MNIST", "CovType"]:
    # for dataset in ["10X_PBMC", "Human_kidney", "Mouse_bladder", "Worm_neuron", "CITE_PBMC", "Human_liver", "Baron_human", "Macosko_mouse_retina", "Shekhar_mouse_retina"]:
    for dataset in ["10X_pbmc", "CITE_PBMC", "Human_liver", "Baron_human", "Macosko_mouse_retina", "Shekhar_mouse_retina"]:
        main(dataset)
