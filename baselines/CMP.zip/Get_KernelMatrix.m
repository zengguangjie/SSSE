function [W,L,D]=Get_KernelMatrix(X,gam)
[n,m]=size(X);
if n~=m
    Dis=pdist2(X,X);
    W=exp(-Dis.^2/gam);
else
    W=X;
end
W=W-diag(diag(W));

degs = sum(W, 2);
D    = sparse(1:size(W, 1), 1:size(W, 2), degs);
L = D - W;
degs(degs == 0) = 1e-10;
D = spdiags(1./(degs.^0.5), 0, size(D, 1), size(D, 2));
L = D * L * D;
W=D*W*D;
%L=L-diag(diag(L));
%W=W-diag(diag(W));
end