function H=Label2H(IDX)
    CL=unique(IDX);
    n=length(IDX);
    k1=length(CL);
    %H=zeros(n,k);
    for l=1:k1
        H(:,l)=double((IDX==CL(l))');
    end
    %H=double(H);
end