function [Label] = Semi_Clustering_Single_OLD(X, Q, alpha, k,delta)
[n,m]=size(X);
[W,~]=Get_KernelMatrix(X,delta);
Ma=max(W(:));
Mi=min(W(:));
I=(Q(:)>0);
I2=(Q(:)<0);
Q(I)=(Ma-W(I));
Q(I2)=(Mi-W(I2));
%[W1,~]=Get_KernelMatrix(W+alpha*Q,delta);
W1=W+alpha*Q;
[U, ~] = eigs(W1,k) ;
U = bsxfun( @rdivide, U, sqrt(sum(U.*U,2)) );

%���ò�ξ���õ����ջ��ֽ��
U=real(U);
Z = linkage(U,'ward','euclidean');
Label = cluster(Z,'maxclust',k);


end