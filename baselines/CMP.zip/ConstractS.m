function [W,S] = ConstractS( X ,delta)
Dis=pdist2(X,X);
%sigsq=sigsq/delta;


 %W=exp(E/(2*(sigsq^2)));
%W=exp(E/(2*(sigsq)));
W=exp(-Dis.^2/delta);
%W=W-diag(diag(W));
%����Ⱦ���D
%D=diag(sum(W,2));
degs = sum(W, 2);
D    = sparse(1:size(W, 1), 1:size(W, 2), degs);

% compute unnormalized Laplacian
%L = D - W;

% compute normalized Laplacian if needed
% avoid dividing by zero
degs(degs == 0) = eps;
% calculate D^(-1/2)
D = spdiags(1./(degs.^0.5), 0, size(D, 1), size(D, 2));

%�淶����������
S=D*W*D;
S=S-diag(diag(S));
end

