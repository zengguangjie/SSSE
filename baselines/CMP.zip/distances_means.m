function m=distances_means(data)
D=pdist2(data,data);
m=mean(D(:));
end