% datasets = ["Yale", "ORL", "COIL20", "COIL100", "USPS", "MNIST", "CovType"];
% datasets = ["10X_PBMC", "Human_kidney", "Mouse_bladder", "Worm_neuron", "CITE_PBMC", "Human_liver", "Baron_human"];
datasets = ["2100cells/mouse_bladder", "2100cells/worm_neuron", "2100cells/human_kidney", "2100cells/10X_PBMC"];
for index = 1:length(datasets)


dataseti = convertStringsToChars(datasets(index))

inputName = ['datasets/', dataseti, '.mat'];
data = load(inputName);
X = double(data.fea);
X = NormalizeFea(double(X));
y = double(data.gnd);
k=max(y);
delta = 0.01;
ARIs = [];
NMIs = [];
times = [];
for repeat_time = 1:10
tStart = tic;

sizeX = size(X);
N = int32(0.2*sizeX(1));
[Q, H, H1] = Get_Constraints(y,N,"PNL");
y_pred = Semi_Clustering_Single_OLD(X, Q, 1, k,delta);
tEnd = toc(tStart);
[statistic,ACC,PE,RE,ARI,NMI]=accuray_measures(y_pred,y);

ARI, NMI
ARIs = [ARIs,ARI];
NMIs = [NMIs,NMI];
times = [times, tEnd];
end
mean(ARIs), mean(NMIs)

score_fname = ['label/', dataseti, '.txt'];
fid = fopen(score_fname, 'w');
fprintf(fid, 'ARI\t');
for i = 1:length(ARIs)
    fprintf(fid, '%.8f\t', ARIs(i));
end
fprintf(fid, 'average: %.8f\t', mean(ARIs));
fprintf(fid, 'std: %.8f\n NMI:\t', std(ARIs));
for i = 1:length(NMIs)
    fprintf(fid, '%.8f\t', NMIs(i));
end
fprintf(fid, 'average: %.8f\t', mean(NMIs));
fprintf(fid, 'std: %.8f\n times:\t', std(NMIs));

for i = 1:length(times)
    fprintf(fid, '%.8f\t', times(i));
end
fprintf(fid, 'average: %.8f\t', mean(times));
fprintf(fid, 'std: %.8f\n', std(times));

end
