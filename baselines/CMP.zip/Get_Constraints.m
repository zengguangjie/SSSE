function [Q,H,H1]=Get_Constraints(class,N,Type)
R=length(class);
C=Label2H(class);
CC=sparse(C*C');
CC=CC-diag(diag(CC));
H1=[];
if strcmp(Type,'ML')
    M=sparse(R,R);
    Tmp=randperm(R^2);
    I=find(CC(Tmp)>0);
    M(Tmp(I(1:N)))=1;
    M=M+M';
    %t1=0;
%     while t1<N
%         X1=unidrnd(R);
%         X2=unidrnd(R);
%         if X1~=X2 && class(X1)==class(X2) && M(X1,X2)==0
%             M(X1,X2)=1;
%             M(X2,X1)=1;
%             t1=t1+1;
%         end
%     end
    GM=digraph(M);
    BM=transclosure(GM);
    M=adjacency(BM);
    Q=M;
    H=M;
%     IP=find(sum(Q,2)>0);
%     Po=(max(max(W))-W(IP,IP)).*Q(IP,IP);
%     Q(IP,IP)=Po;
end

if strcmp(Type,'PL')
    Label=unique(class);
    k=length(Label);
    PL=zeros(R,k);    
    t=0;
    %IP=zeros(1,N);
    while t<N
        X=unidrnd(R);
        Y=unidrnd(k);
        if PL(X,Y)==0 && class(X)==Label(Y)
            PL(X,Y)=1;
            %PL(X,setdiff([1:k],Y))=-1;
            t=t+1;
            %IP(t)=Y;
        end
    end    
    Q=sparse(PL*PL');
    IP=find(sum(Q,2)>0);
    %Q(IP,IP)=Q(IP,IP)-eye(length(IP));
    No=Q(IP,IP)-1;
    Po=Q(IP,IP);
    Q(IP,IP)=Po+No;
    H=PL;
end


if strcmp(Type,'CL')
    C=sparse(R,R);
    Tmp=randperm(R^2);
    I=find(CC(Tmp)==0);
    C(Tmp(I(1:N)))=-1;
    C=C+C';
%     t2=0;
%     while t2<N
%         X1=unidrnd(R);
%         X2=unidrnd(R);
%         if X1~=X2 && class(X1)~=class(X2) && C(X1,X2)==0
%             C(X1,X2)=-1;
%             C(X2,X1)=-1;
%             t2=t2+1;
%         end
%     end
    Q=C;
    H=C;
%     IP=find(sum(Q,2)<0);
%     No=(W(IP,IP)-min(min(W))).*Q(IP,IP);
%     Q(IP,IP)=No;
end



if strcmp(Type,'NL')
    Label=unique(class);
    k=length(Label);
    NL=zeros(R,k);    
    t=0;
    while t<N
        X=unidrnd(R);
        Y=unidrnd(k);
        if NL(X,Y)==0 && class(X)~=Label(Y)
            NL(X,Y)=-1;
            t=t+1;
        end
    end   
    D=-sum(NL,2);
    F=find(D==(k-1));
    Q=sparse(R,R);
    %A=zeros(R,k);
    A=double(NL(F,:)==0);
    A1=A*A';
    A1=double(A1>0)-double(A1==0);
    Q(F,F)=A1;
%     A=NL(F,:)*NL(F,:)'/(k-1);
%     OI=find(A(:)>0 & A(:)<1);
%     A(OI)=-1;
%     Q(F,F)=A;
%     %IP=find(Q(:)>0);
%     %Po=(max(max(W))-W(IP)).*Q(IP);
%     %Q(IP)=Po;
%     IP=find(Q(:)<0);
%     %No=(W(IP)-min(min(W))).*Q(IP);
%     Q(IP)=-Q(IP);
    H=NL;
end

if strcmp(Type,'PNL')
    Label=unique(class);
    k=length(Label);
    PL=zeros(R,k);
    NL=zeros(R,k);    
    t=0;
    t1=0;
    while t<N/2 
        X=unidrnd(R);
        Y=unidrnd(k);
        if PL(X,Y)==0 && class(X)==Label(Y)
            PL(X,Y)=1;
            t=t+1;
        end
    end
    Z=(sum(PL,2)>0);
    while t1<N/2
        X=unidrnd(R);
        Y=unidrnd(k);
        if Z(X)==0 && NL(X,Y)==0 && class(X)~=Label(Y)
           NL(X,Y)=-1;
            t1=t1+1;
        end         
    end 
  
    D=-sum(NL,2);
    F=find(D==(k-1));
    PL(F,:)=double(NL(F,:)==0);
    Q=sparse(PL*PL');
    IP=find(sum(Q,2)>0);
    
    
    %Q1(IP,IP)=Q1(IP,IP)-eye(length(IP));
    No=Q(IP,IP)-1;
    Po=Q(IP,IP);
    Q(IP,IP)=Po+No;
    H=PL;
    H1=NL;

%     D=-sum(NL,2);
%     F=find(D==(k-1));
%     Q=sparse(R,R);
%     %A=zeros(R,k);
%     A=double(NL(F,:)==0);
%     A1=A*A';
%     IP=find(sum(A1,2)>0);
%     %A1(IP,IP)=A1(IP,IP)-eye(length(IP));
%     No=A1(IP,IP)-1;
%     Po=A1(IP,IP);
%     A1(IP,IP)=Po+No;
%     %A1=double(A1>0)-double(A1==0);
%     Q(F,F)=A1;
%     Q=Q+Q1;
   
    
   
end

if strcmp(Type,'MCL')
    M=sparse(R,R);
    Tmp=randperm(R^2);
    I=find(CC(Tmp)>0);
    M(Tmp(I(1:N/2)))=1;
    M=double(M+M'>0);
    
    GM=digraph(M);
    BM=transclosure(GM);
    M=adjacency(BM);
    
    C=sparse(R,R);
    Tmp=randperm(R^2);
    I=find(CC(Tmp)==0);
    C(Tmp(I(1:N/2)))=-1;

    
    [I,J]=find(C);
    t=length(I);
    for q=1:t
        C(M(I(q),:)>0,M(J(q),:)>0)=-1;
    end
%     Bins=conncomp(BM);
%     CL=unique(Bins);
%     kc=length(CL);
%     for i=1:kc
%         U(:,i)=(Bins==CL(i));
%     end
%     for i=1:kc
%         for j=i+1:kc
%             if sum(sum(C(U(:,i),U(:,j))))<0
%                C(U(:,i),U(:,j))=-1;
%                C(U(:,j),U(:,i))=-1;
%             end
%         end
%     end
    C=-double(C+C'<0);
    Q=M+C;
    H=Q;   
end

    
end