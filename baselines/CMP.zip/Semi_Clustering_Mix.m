function [Label] = Semi_Clustering_Mix(X, S, m,k,alpha,delta)
[n,~]=size(X);
[W,~]=Get_KernelMatrix(X,delta);
Ma=max(W(:));
Mi=min(W(:));
Q=sparse(n,n);
for i=1:m
    Q=Q+S{i};
end
I=find(Q(:)>0);
I2=find(Q(:)<0);

Q(I)=(Ma-W(I));
Q(I2)=(Mi-W(I2));
%[W1,~]=Get_KernelMatrix(W+alpha*Q,delta);
W1=W+alpha*Q;
[U, ~] = eigs(W1,k) ;
U = bsxfun( @rdivide, U, sqrt(sum(U.*U,2)) + 1e-10 );

U=real(U);
Z = linkage(U,'ward','euclidean');
Label = cluster(Z,'maxclust',k);

end