import numpy as np
import h5py
from sklearn.metrics import adjusted_rand_score, normalized_mutual_info_score
from sklearn.preprocessing import MinMaxScaler
import scipy
import networkx as nx
from queue import Queue
from ete3 import Tree

def ete_tree_get_direct_parent(tree:Tree):
    direct_parent = []
    q = Queue()
    depth_order = []
    q.put(tree.get_tree_root())
    # depth_order.append(tree.get_tree_root())
    leaves = tree.get_tree_root().get_leaves()
    instances = [int(leave.name) for leave in leaves]
    # n_instance = len(instances)
    n_instance = np.max(instances)+1
    while q.qsize()>0:
        nodei = q.get()
        depth_order.append(nodei)
        for child in nodei.get_children():
            q.put(child)
    depth_order.reverse()
    cur_node = np.max(instances)+1
    for nodei in depth_order:
        children = nodei.get_children()
        if len(children) > 0:
            nodei.name = str(cur_node)
            for child in children:
                direct_parent.append([int(child.name), int(nodei.name)])
            cur_node += 1
    direct_parent = np.array(direct_parent)
    return direct_parent, n_instance, cur_node

def _get_parent(direct_parent: np.ndarray, n_instance: int, n_node: int):
    parent_matrix = np.zeros(
        shape=[n_instance, n_node], dtype=np.int8)
    for i in range(direct_parent.shape[0]):
        current_ind = []
        if direct_parent[i,0] >= n_instance:
            ind = np.argwhere(parent_matrix[:, int(direct_parent[i,0])] == 1).flatten()
            for item in ind:
                current_ind.append(item)
        else:
            current_ind.append(int(direct_parent[i, 0]))
        parent_matrix[current_ind, direct_parent[i,1]] = 1
    parent_matrix = np.delete(parent_matrix, np.s_[:n_instance], axis=1)
    return parent_matrix

def _get_node_purity(parent_matrix: np.ndarray, y: np.array, n_node):
    n_instance = len(y)
    y_label = np.unique(y)
    node_purity = np.zeros(shape=(len(y_label), n_node))
    subtree_sum = np.ones(n_instance, dtype=np.int64)

    for ci in range(len(y_label)):
        ind = np.argwhere(y == y_label[ci]).flatten()
        node_purity[ci, ind] = 1
        for ti in range(n_node)[n_instance:]:
            Tinstances = np.argwhere(
                parent_matrix[:, ti - n_instance] == 1).flatten()
            p = 0
            for item in Tinstances:
                p = p + node_purity[ci, item] * subtree_sum[item]
            node_purity[ci, ti] = p / sum(subtree_sum[Tinstances])
    return node_purity

def dendrogram_purity(tree: Tree, y: np.array):
    direct_parent, n_instance, n_node = ete_tree_get_direct_parent(tree)
    print(direct_parent)
    assert n_instance==len(y)
    parent_matrix = _get_parent(direct_parent=direct_parent, n_instance=n_instance, n_node=n_node)
    print(parent_matrix)
    node_purity = _get_node_purity(parent_matrix=parent_matrix, y=y, n_node=n_node)
    print(node_purity)
    y_label = np.unique(y)
    purity = 0
    s = 0
    for ci in range(len(y_label)):
        current_instances = np.argwhere(y == y_label[ci]).flatten()
        for i in range(len(current_instances)):
            for j in range(len(current_instances))[i + 1:]:
                purity += _purity_score(current_instances[i], current_instances[j], ci,
                                        parent_matrix, node_purity, n_instance)
                s += 1
    purity = purity / s
    return purity


def _purity_score(i: int, j: int, ci: int, parent_matrix: np.ndarray, node_purity: np.ndarray, n_instances: int):
    if i == j:
        score = node_purity[ci, i]
    else:
        lca = np.argwhere(parent_matrix[i, :] *
                          parent_matrix[j, :] == 1).flatten()[0]
        score = node_purity[ci, lca + n_instances]
    return score