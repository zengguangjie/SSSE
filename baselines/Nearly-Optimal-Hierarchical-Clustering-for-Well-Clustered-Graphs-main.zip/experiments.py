import sys
sys.path.append('/home/zengguangjie/SSSE')

import numpy as np
from sklearn.preprocessing import MinMaxScaler, StandardScaler
import scipy
import networkx as nx
from spectral_degree_clustering import spectral_degree_clustering
from queue import Queue
from ete3 import Tree
from tqdm import tqdm
import itertools
import pynndescent
import time

def tree2_etetree(tree):
    q = Queue()
    q.put(tree)
    while q.qsize()>0:
        list0 = q.get()
        if len(list0)==3:
            list0.pop(-1)
            if len(list0[0])==1:
                list0[0] = list0[0][0]
            else:
                q.put(list0[0])
            if len(list0[1])==1:
                list0[1] = list0[1][0]
            else:
                q.put(list0[1])
    return tree


def dendrogram_purity_expected(t, y, n_sample=1000):
    n_instance = y.shape[0]
    y = y.astype(int)
    y_onehot = np.zeros((y.shape[0], y.max() + 1))
    y_onehot[np.arange(y.shape[0]), y] = 1
    cluster_dict = {}
    for i in range(y_onehot.shape[1]):
        indicesi = np.argwhere(y_onehot[:, i] == 1).flatten()
        cluster_indices = np.argwhere(y_onehot[:, i] == 1).flatten().tolist()
        for j in indicesi:
            cluster_dict[j] = cluster_indices
    purity_list = []
    leaves_dict = {}
    for leaf in t.get_leaves():
        leaves_dict[int(leaf.name)] = leaf
    for index_sample in tqdm(range(n_sample)):
        nodeID_i = np.random.randint(n_instance)
        cluster_indices = cluster_dict[nodeID_i]
        nodeID_j = np.random.choice(cluster_indices)
        nodei = leaves_dict[nodeID_i]
        nodej = leaves_dict[nodeID_j]
        ancestor = t.get_common_ancestor(nodei, nodej)
        ancestor_leaves = [int(i.name) for i in ancestor.get_leaves()]
        assert nodeID_i in ancestor_leaves
        assert nodeID_j in ancestor_leaves
        purity = len(set(ancestor_leaves).intersection(cluster_indices)) / len(ancestor_leaves)
        purity_list.append(purity)
    return np.mean(purity_list)

def SpecWRSC_ordinary(path):
    hie_knn_k = 7
    f = scipy.io.loadmat(path)
    X = np.array(f["fea"]).astype(float)
    X = StandardScaler().fit_transform(X)
    y = np.array(f['gnd']).astype(float).squeeze()
    index = pynndescent.NNDescent(X, metric='cosine', n_neighbors=100, pruning_degree_multiplier=10.0)
    ann_data = {}
    ann_data['ind'] = index.neighbor_graph[0]
    ann_data['dist'] = index.neighbor_graph[1]
    ind_knn = np.array(ann_data['ind']).astype(int)[:,1:hie_knn_k]
    dist_knn = np.array(ann_data['dist']).astype(float)[:,1:hie_knn_k]
    weight_knn = ((1-dist_knn)+1)/2
    G = nx.Graph()
    for i in range(ind_knn.shape[0]):
        for index_nn in range(ind_knn.shape[1]):
            j = ind_knn[i, index_nn]
            if i == j:
                continue
            weight_ij = weight_knn[i, index_nn]
            if not G.has_edge(i,j):
                G.add_edge(i,j,weight=weight_ij)
                G.add_edge(j,i,weight=weight_ij)

    final_tree, cost = spectral_degree_clustering(G, np.unique(y).shape[0])
    print("SpecWRSC ends")
    t = tree2_etetree(final_tree)
    t = Tree(t.__str__().replace('[', '(').replace(']', ')')+";", format=9)
    return dendrogram_purity_expected(t, y)

if __name__=='__main__':
    # for dataset in ["Yale", "ORL", "COIL20", "COIL100", "USPS", "MNIST", "CovType"]:
    for dataset in ["Yale"]:
        path = "/home/zengguangjie/SSSE/datasets/{}.mat".format(dataset)
        DPs = []
        times = []
        with open("results/{}.txt".format(dataset), 'w') as f:
            for i in range(10):
                time1 = time.time()
                DP = SpecWRSC_ordinary(path)
                time2 = time.time()
                DPs.append(DP)
                times.append(time2 - time1)

            f.write("DP:\t")
            for i in range(len(DPs)):
                f.write("{}\t".format(DPs[i]))
            f.write("average:\t{}\t".format(np.mean(DPs)))
            f.write("std:\t{}\n".format(np.std(DPs)))

            f.write("time:\t")
            for i in range(len(times)):
                f.write("{}\t".format(times[i]))
            f.write("average:\t{}\t".format(np.mean(times)))
            f.write("std:\t{}\n".format(np.std(times)))

            print(np.mean(DPs))
